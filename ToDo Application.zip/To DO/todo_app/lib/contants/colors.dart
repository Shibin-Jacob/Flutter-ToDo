import 'package:flutter/material.dart';

const Color tgRed = Color(0xffda4040);
const Color tgBlue = Color(0xff5f52ee);

const Color tgBlack = Color(0xff3a3a3a);
const Color tgGrey = Color(0xff717171);

const Color tgBGColor = Color(0xffeeeff5);